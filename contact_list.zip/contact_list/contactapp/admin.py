from django.contrib import admin
from .models import City, Contact
# Register your models here.
admin.site.register(City)
admin.site.register(Contact)