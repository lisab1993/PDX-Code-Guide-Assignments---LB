Feature 1:
-shows a list of to do items
-the can be expanded to show the text, which has details for the item. 



Feature 2:
-create a to do item
-there will be a title and text

Feature 3:
-delete a todo item

Feature 3:
-edit a todo item

Feature 4:
-mark as complete




Stretch Goal
Goal 1:
-upload images

Goal 1.5:
-include dates



Goal 2:
-maybe a more detailed view?