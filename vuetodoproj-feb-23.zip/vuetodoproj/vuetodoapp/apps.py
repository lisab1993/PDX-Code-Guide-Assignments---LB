from django.apps import AppConfig


class VuetodoappConfig(AppConfig):
    name = 'vuetodoapp'
